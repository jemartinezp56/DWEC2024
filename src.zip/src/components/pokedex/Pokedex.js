import React, { useState, useEffect } from "react";
import './Pokedex.css';

const Pokedex = ({ onSelect, onBack, battleMode = false }) => {
  const [pokemonList, setPokemonList] = useState([]);
  const [selected, setSelected] = useState([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [filterType, setFilterType] = useState('');
  const [selectedPokemon, setSelectedPokemon] = useState(null); 

  useEffect(() => {
    fetch("https://pokeapi.co/api/v2/pokemon?limit=1025")
      .then((response) => response.json())
      .then((data) => {
        const fetches = data.results.map((p) =>
          fetch(p.url).then((res) => res.json())
        );
        Promise.all(fetches).then((results) => setPokemonList(results));
      });
  }, []);

  const filteredPokemonList = pokemonList.filter((pokemon) => {
    const matchesSearch = pokemon.name.toLowerCase().includes(searchTerm.toLowerCase());

    const matchesType = filterType
      ? pokemon.types.some((type) => type.type.name === filterType)
      : true;

    return matchesSearch && matchesType;
  });

  const handleSelect = (pokemon) => {
    if (!battleMode) {
      setSelectedPokemon(pokemon); 
      return;
    }
    if (selected.includes(pokemon)) {
      setSelected(selected.filter((p) => p !== pokemon));
    } else if (selected.length < 2) {
      setSelected([...selected, pokemon]);
    }
  };

  return (
    <div className="pokedex-container">
      <h2>Pokédex</h2>
      <button onClick={onBack}>Back to Menu</button>

      {battleMode && selected.length === 2 && (
        <button className="start-battle-btn" onClick={() => onSelect(selected[0].name, selected[1].name)}>
          Start Battle
        </button>
      )}

      {/* Barra de búsqueda más larga */}
      <input
        type="text"
        placeholder="Buscar Pokémon..."
        value={searchTerm}
        onChange={(e) => setSearchTerm(e.target.value)}
        style={{
          margin: "10px 0", 
          padding: "5px", 
          width: "100%",  // Barra más ancha
          maxWidth: "600px",  // Limitar el tamaño máximo
          display: "block",
          boxSizing: "border-box"
        }}
      />
      
      {/* Filtro por Tipo */}
      <select
        onChange={(e) => setFilterType(e.target.value)}
        value={filterType}
        style={{
          margin: "10px 0", 
          padding: "5px",
          width: "100%", 
          maxWidth: "200px", 
          display: "block",
          boxSizing: "border-box"
        }}
      >
        <option value="">Filtrar por tipo</option>
        <option value="fire">Fuego</option>
        <option value="water">Agua</option>
        <option value="grass">Planta</option>
        <option value="electric">Eléctrico</option>
        <option value="bug">Bicho</option>
        <option value="dragon">Dragón</option>
        <option value="fairy">Hada</option>
        <option value="ghost">Fantasma</option>
        <option value="normal">Normal</option>
        <option value="psychic">Psíquico</option>
        {/* Otros tipos */}
      </select>

      {/* Mostrar Pokémon filtrados */}
      <div className="pokemon-grid">
        {filteredPokemonList.map((pokemon) => (
          <div
            key={pokemon.name}
            onClick={() => handleSelect(pokemon)}
            className={`pokemon-card ${selected.includes(pokemon) ? 'selected' : ''}`}
          >
            <img src={pokemon.sprites.front_default} alt={pokemon.name} />
            <p>{pokemon.name}</p>
          </div>
        ))}
      </div>

      {/* Mostrar detalles del Pokémon seleccionado */}
      {selectedPokemon && (
        <div style={{ marginTop: "20px" }}>
          <h3>{selectedPokemon.name.charAt(0).toUpperCase() + selectedPokemon.name.slice(1)}</h3>
          <img src={selectedPokemon.sprites.front_default} alt={selectedPokemon.name} />
          
          {/* Mostrar los stats */}
          <div style={{ marginTop: "10px" }}>
            <p><strong>Stats:</strong></p>
            <ul>
              <li><strong>HP:</strong> {selectedPokemon.stats[0].base_stat}</li>
              <li><strong>Attack:</strong> {selectedPokemon.stats[1].base_stat}</li>
              <li><strong>Defense:</strong> {selectedPokemon.stats[2].base_stat}</li>
              <li><strong>Special Attack:</strong> {selectedPokemon.stats[3].base_stat}</li>
              <li><strong>Special Defense:</strong> {selectedPokemon.stats[4].base_stat}</li>
              <li><strong>Speed:</strong> {selectedPokemon.stats[5].base_stat}</li>
            </ul>
          </div>
        </div>
      )}
    </div>
  );
};

export default Pokedex;
