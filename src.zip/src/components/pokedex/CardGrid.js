import React from 'react';
import Loading from '../Loading';
import Cards from './Cards';
import './CardGrid.css'; // Ajusta la ruta si es necesario

const CardGrid = ({ pokedex, isLoading, query, typeFilter }) => {

    // Función de búsqueda por nombre
    const searchedPokemon = (pokedex) => {
        return pokedex.filter(pokemon => pokemon.name.toLowerCase().includes(query.toLowerCase()));
    }

    // Función de filtrado por tipo
    const filteredPokemon = (pokedex) => {
        return pokedex.filter(pokemon => pokemon.type.some(type => typeFilter.includes(type)));
    }

    let sortedPokemon = []

    // Si no hay filtro de tipo, solo buscamos por nombre
    if (typeFilter.length === 0) {
        sortedPokemon = searchedPokemon(pokedex);
    } else {
        sortedPokemon = searchedPokemon(filteredPokemon(pokedex));
    }

    return (
        isLoading ? (
            <Loading />
        ) : (
            <section className='container'>
                {sortedPokemon.length > 0 ? (
                    sortedPokemon.map((pokemon) => (
                        <div key={pokemon.id} className='cards'>
                            <Cards key={pokemon.id} pokemon={pokemon} />
                        </div>
                    ))
                ) : (
                    <p>No Pokémon found</p>
                )}
            </section>
        )
    );
}

export default CardGrid;
