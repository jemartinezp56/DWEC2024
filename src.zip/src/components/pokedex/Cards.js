import React from 'react';
import '../../App.css'; // Ajusta la ruta si es necesario
import './Cards.css';

const Cards = ({ pokemon }) => {
    return (
        <div className="card">
            <div className='card-inner'>
                <div className='card-front capitalise'>
                    <div className='image-background'>
                        {/* Mostrar imagen de Pokémon */}
                        <img src={pokemon.sprites?.front_default || '/default-image.png'} alt={pokemon.name} />
                    </div>

                    <h1 className='pokemon-title'>{pokemon.name}</h1>

                    {/* Muestra los tipos de Pokémon */}
                    <p className='pokemon-types'>
                        Type: {pokemon.types && pokemon.types.length > 0 ? 
                            pokemon.types.map((type, index) => (
                                <span key={index}>{type.type.name + '\u00a0'}</span>
                            )) : 'No types available'}
                    </p>
                </div>

                <div className='card-back'>
                    <div className='image-background'>
                        {/* Imagen en la parte trasera de la carta */}
                        <img src={pokemon.sprites?.back_default || '/default-back-image.png'} alt={`Behind ${pokemon.name}`} />
                    </div>
                    <h2 className='stats-title'>Stats</h2>
                    <ul className='stats'>
                        {/* Estadísticas de los Pokémon */}
                        <li>Hp: {pokemon.stats?.find(stat => stat.stat.name === 'hp')?.base_stat}</li>
                        <li>Attack: {pokemon.stats?.find(stat => stat.stat.name === 'attack')?.base_stat}</li>
                        <li>Defence: {pokemon.stats?.find(stat => stat.stat.name === 'defense')?.base_stat}</li>
                        <li>SpAtk: {pokemon.stats?.find(stat => stat.stat.name === 'special-attack')?.base_stat}</li>
                        <li>SpDef: {pokemon.stats?.find(stat => stat.stat.name === 'special-defense')?.base_stat}</li>
                        <li>Speed: {pokemon.stats?.find(stat => stat.stat.name === 'speed')?.base_stat}</li>
                    </ul>               
                </div>
            </div>
        </div>
    )
}

export default Cards;
