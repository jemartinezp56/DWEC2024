import React from 'react';

const Filters = ({ pokedex, isLoading, getFilter }) => {
    const types = pokedex
        .map((pokemon) => pokemon.types)  // Obtenemos los tipos de los Pokémon
        .flat()  // Aplanamos los arrays de tipos en un solo array
        .map((type) => type.type.name)  // Obtenemos solo el nombre del tipo
        .filter((value, index, self) => self.indexOf(value) === index)  // Filtramos los tipos únicos
        .sort();  // Ordenamos alfabéticamente

    const onClick = () => {
        let checked = Array.from(document.querySelectorAll('input[type=checkbox]:checked'));  // Obtiene los checkboxes seleccionados
        const selected = checked.map((check) => check.value);  // Extrae los valores de los checkboxes
        getFilter(selected);  // Llama a getFilter para pasar los tipos seleccionados
    };

    const onReset = () => {
        let checked = Array.from(document.querySelectorAll('input[type=checkbox]:checked'));  // Obtiene los checkboxes seleccionados
        checked.forEach((el) => (el.checked = false));  // Desmarca todos los checkboxes
        onClick();  // Aplica el filtro con un array vacío
    };

    return isLoading ? (
        ''
    ) : (
        <ul className='filter'>
            <h2>Types</h2>
            {types.map((type) => (
                <li key={type} className='check'>
                    <input
                        type='checkbox'
                        id={type}
                        name={type}
                        value={type}
                        onClick={() => onClick()}
                    />
                    <label className='capitalise filter-types' htmlFor={type}>
                        {type}
                    </label>
                    <br />
                </li>
            ))}
            <button className='button' onClick={onReset}>
                Reset types
            </button>
        </ul>
    );
};

export default Filters;
