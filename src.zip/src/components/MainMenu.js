import React, { useState } from "react";
import Pokedex from "./pokedex/Pokedex";
import Battle from "./Battle";
import './MainMenu.css'; 

const MainMenu = () => {
  const [screen, setScreen] = useState("menu");
  const [selectedPokemon, setSelectedPokemon] = useState([]);

  const startBattle = (pokemon1, pokemon2) => {
    setSelectedPokemon([pokemon1, pokemon2]);
    setScreen("battle");
  };

  return (
    <div className="main-menu-container">
      {screen === "menu" && (
        <div>
          <h1>Menú Principal</h1>
          <button className="main-menu-button" onClick={() => setScreen("pokedex")}>Ir a la Pokédex</button>
          <button className="main-menu-button" onClick={() => setScreen("battle-setup")}>Empezar Batalla</button>
        </div>
      )}
      {screen === "pokedex" && <Pokedex onBack={() => setScreen("menu")} />}
      {screen === "battle-setup" && (
        <div>
          <h2>Selecciona 2 Pokemons para combatir</h2>
          <Pokedex
            onSelect={(pokemon1, pokemon2) => startBattle(pokemon1, pokemon2)}
            battleMode={true}
          />
        </div>
      )}
      {screen === "battle" && (
        <Battle
          pokemon1={selectedPokemon[0]}
          pokemon2={selectedPokemon[1]}
          onBack={() => setScreen("menu")}
        />
      )}
    </div>
  );
};

export default MainMenu;
