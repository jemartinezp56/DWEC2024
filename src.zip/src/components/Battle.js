import React, { useState, useEffect } from "react";
import './Battle.css';

const Battle = ({ pokemon1, pokemon2, onBack }) => {
  const [hp1, setHp1] = useState(100);
  const [hp2, setHp2] = useState(100);
  const [log, setLog] = useState([]);
  const [pokemon1Image, setPokemon1Image] = useState(null);
  const [pokemon2Image, setPokemon2Image] = useState(null);
  const [turn, setTurn] = useState('pokemon1');  // Controla el turno del combate
  const [gameOver, setGameOver] = useState(false);  // Controla si el juego ha terminado

  useEffect(() => {
    // Obtener las imágenes de los Pokémon
    fetch(`https://pokeapi.co/api/v2/pokemon/${pokemon1}`)
      .then(response => response.json())
      .then(data => setPokemon1Image(data.sprites.front_default));

    fetch(`https://pokeapi.co/api/v2/pokemon/${pokemon2}`)
      .then(response => response.json())
      .then(data => setPokemon2Image(data.sprites.front_default));
  }, [pokemon1, pokemon2]);

  useEffect(() => {
    if (hp1 <= 0 || hp2 <= 0 || gameOver) return;

    // Realiza los ataques de forma alterna entre los Pokémon
    const attack1 = Math.floor(Math.random() * 20) + 10;
    const attack2 = Math.floor(Math.random() * 20) + 10;

    if (turn === 'pokemon1') {
      setHp2(prev => Math.max(prev - attack1, 0)); // Reduce HP de pokemon2
      setLog(prev => [
        ...prev,
        `${pokemon1} usa un ataque rápido y hace ${attack1} de daño a ${pokemon2}!`
      ]);
      setTurn('pokemon2');  // Cambia el turno al segundo Pokémon
    } else if (turn === 'pokemon2') {
      setHp1(prev => Math.max(prev - attack2, 0)); // Reduce HP de pokemon1
      setLog(prev => [
        ...prev,
        `${pokemon2} usa una mordida feroz y hace ${attack2} de daño a ${pokemon1}!`
      ]);
      setTurn('pokemon1');  // Cambia el turno al primer Pokémon
    }

  }, [turn, hp1, hp2, pokemon1, pokemon2, gameOver]);

  useEffect(() => {
    if (hp1 <= 0 || hp2 <= 0) {
      setGameOver(true);
    }
  }, [hp1, hp2]);

  return (
    <div className="battle-container">
      <h2>¡Combate: {pokemon1} vs {pokemon2}!</h2>

      <div className="battle-pokemon">
        <div className="pokemon-box">
          <img src={pokemon1Image} alt={pokemon1} className="pokemon-img" />
          <p><strong>{pokemon1}</strong> HP: {hp1}</p>
        </div>

        <div className="pokemon-box">
          <img src={pokemon2Image} alt={pokemon2} className="pokemon-img" />
          <p><strong>{pokemon2}</strong> HP: {hp2}</p>
        </div>
      </div>

      <div className="battle-log">
        {gameOver && (
          <>
            {hp1 <= 0 && <h3>{pokemon2} ¡Gana el combate!</h3>}
            {hp2 <= 0 && <h3>{pokemon1} ¡Gana el combate!</h3>}
          </>
        )}
      </div>

      <div className="battle-log">
        {log.map((entry, index) => (
          <p key={index}>{entry}</p>
        ))}
      </div>

      <button onClick={onBack} className="back-button">Volver al Menú</button>
    </div>
  );
};

export default Battle;
